## Famous speeches by technology advocates and contributors

This repository is a compilation of some of my favorite speeches and quotes from renowned technology advocates and contributors.

They are contained in the examples.md file.
