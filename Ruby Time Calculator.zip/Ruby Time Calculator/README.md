## Famous speeches by technology advocates and contributors

This repository is a compilation of speeches and quotes from renowned technology advocates and contributors including [Grace Hopper](https://en.wikipedia.org/wiki/Grace_Hopper), [Edsger Djikstra](https://en.wikipedia.org/wiki/Edsger_W._Dijkstra), and [Alan Turing](https://en.wikipedia.org/wiki/Alan_Turing).
